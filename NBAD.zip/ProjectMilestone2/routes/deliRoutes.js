const express = require('express');
const controller = require('../controllers/deliController');

const router = express.Router();

router.get('/', controller.index);

router.get('/Menu', controller.Menu);

router.get('/MenuDetails/:id', controller.MenuDetails);

router.get('/New', controller.New);

router.post('/NewServing', controller.createNew);

router.get('/MenuDetails/:id/edit', controller.edit);

router.put('/MenuDetails/:id/MenuDetails/:id', controller.update);

router.delete('/MenuDetails/:id', controller.delete);

router.get('/UnderMaintainence', controller.UnderMaintainence);

router.get('/LogIn', controller.LogIn);

router.get('/SignUp', controller.SignUp);

router.get('/About', controller.About);

router.get('/ContactUs', controller.ContactUs);

module.exports = router;