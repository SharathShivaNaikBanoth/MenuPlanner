const models = require('../models/GDdeli');

exports.index = (req, res, next) => {
    // res.send("in / route -> render Home Page");
    res.render('./index.ejs');
};

exports.Menu = (req, res, next) => {
    // res.send("in /Menu route -> show Menu");
    let delis = models.find();
    res.render('deli/Menu.ejs', {delis})
};

exports.MenuDetails = (req, res, next) => {
    // res.send("in /MenuDetails/:id route -> show specific deli");
    let id = req.params.id
    let deli = models.findByID(id);
    if(deli) {
        res.render('./deli/MenuDetails.ejs', {deli});
    } else {
        let err = new Error ("Story out of Bounds");
        err.status = 404;
        next(err);

        // res.status(404).send('Story out of bound');
    }
};

exports.edit = (req, res, next) => {
    // res.send("send edit form");
    let id = req.params.id
    let deli = models.findByID(id);
    
    if(deli) {
        res.render('./deli/edit.ejs', {deli});
    } else {
        // res.status(404).send('Story out of bound');

        let err = new Error ("Story out of Bounds");
        err.status = 404;
        next(err);
    }
};

exports.update = (req, res, next) => {
    // res.send("in /{id} -> edit a story -- PUT");
    let deli = req.body;
    let update = models.updateByID(req.params.id, deli);
    //console.log(deli)
    if (update) {
        res.redirect('/MenuDetails/'+req.params.id);

        // res.redirect('/MenuDetails/'+req.params.id);
    } else {
        // res.status(404).send('Story update Invalid')

        let err = new Error ("Story Update out of Bounds");
        err.status = 404;
        next(err);
    }
};

exports.delete = (req, res, next) => {
    // res.send("deleate a story{id}", req.params.id);
    let id = req.params.id;
    let dlt = models.deleteByID(id);

    if (dlt) {
        res.redirect('/Menu');
    } else {
        // res.status(404).send('Story delete Invalid')

        let err = new Error ("Story Delete out of Bounds");
        err.status = 404;
        next(err);
    }
};
exports.New = (req, res, next) => {
    // res.send("in /New -> create a new story -- GET");
    res.render('./deli/NewServing.ejs');
};


exports.createNew = (req, res, next) => {
    // res.send("in /NewServing -> created a new story -- POST");
    console.log(req.body);
    let createdNew = models.save(req.body);

    if (createdNew) {
        res.redirect('Menu');

        // res.redirect('/MenuDetails/'+req.params.id);
    } else {
        // res.status(404).send('Story update Invalid')

        let err = new Error ("Invalid Deli ... Create a new One (A valid one)");
        err.status = 404;
        next(err);
    }

};

exports.UnderMaintainence = (req, res, next) => {
    // res.send("in /UnderMaintainence");
    res.render('./errHandelig/UnderMaintainence');
};

exports.LogIn = (req, res, next) => {
    res.render('LogIn');
};

exports.SignUp = (req, res, next) => {
    res.render('SignUp');
};

exports.About = (req, res, next) => {
    res.render('About');
};

exports.ContactUs = (req, res, next) => {
    res.render('ContactUs');
};