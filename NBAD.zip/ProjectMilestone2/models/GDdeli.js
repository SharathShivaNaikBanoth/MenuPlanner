const { DateTime } = require('luxon');
const {v4: uuidv4} = require('uuid');

const delis = [
    {
        id: '1',
        category: 'Non-Veg Deli',
        title: 'Hyderabadi Dum Biriyani',
        content: 'Dum Biryani is a spiced mix of meat and rice, traditionally cooked over an open fire in a leather pot. It is combined in different ways with a variety of components to create a number of highly tasty and unique flavor combinations.',
        price: '$14.99',
        createdTime: DateTime.local(2022, 7, 18, 22, 30).toLocaleString(DateTime.DATETIME_SHORT)
        // createdTime: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    },
    {
        id: '2',
        category: 'Non-Veg Deli',
        title: 'Non-Veg Thali',
        content: 'Non-Veg thali is a combination of various dishes put together to make a whole meal. An average non-vegetarian thali usually contains salad, rice, chappati and gravy or dry chicken/mutton/fish dish to go with it.',
        price: '$12.99',
        createdTime: DateTime.local(2022, 7, 18, 22, 30).toLocaleString(DateTime.DATETIME_SHORT)
        // createdTime: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    },
    {
        id: '3',
        category: 'Veg Deli',
        title: 'Veg Spring Rolls',
        content: 'Spring roll is a traditional Chinese savory snack where a pastry sheet is filled with vegetables, rolled & fried. Spring vegetables like cabbage, spring onions and carrots are used for the filling. Since traditionally they were made during the spring festival with spring vegetables, they are known as spring rolls.',
        price: '$9.99',
        createdTime: DateTime.local(2022, 7, 18, 22, 30).toLocaleString(DateTime.DATETIME_SHORT)
        // createdTime: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    },
    {
        id: '4',
        category: 'Veg Deli',
        title: 'Veg Thali',
        content: 'Veg Thali is a combination of main-course gravy, dal or curry, sabzi or stir fry, condiments like raita, chutney, pickle, salad, papadum, and side dishes like roti, naan, chapati, paratha, or boiled rice. Every region in India has its own version of the thali meal.',
        price: '$10',
        createdTime: DateTime.local(2022, 7, 18, 22, 30).toLocaleString(DateTime.DATETIME_SHORT)
        // createdTime: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    },
    {
        id: '5',
        category: 'Dessert',
        title: 'Cheese Cake',
        content: 'Cheesecake is a sweet dessert consisting of one or more layers. The main, and thickest, layer consists of a mixture of a soft, fresh cheese eggs, and sugar.',
        price: '$10',
        createdTime: DateTime.local(2022, 7, 18, 22, 30).toLocaleString(DateTime.DATETIME_SHORT)
        // createdTime: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    },
    {
        id: '6',
        category: 'Dessert',
        title: 'Mango Pudding',
        content: 'Mango Pudding and consists of agar or gelatin, mangoes, evaporated milk, and sugar. In addition, fresh fruit such as strawberries, berries and kiwifruit, can be added as garnish. Served and eaten refrigerator cold, mango pudding has a rich and creamy texture.',
        price: '$10',
        createdTime: DateTime.local(2022, 7, 18, 22, 30).toLocaleString(DateTime.DATETIME_SHORT)
        // createdTime: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    },
];


exports.find = () => {
    return delis;
};

exports.findByID = (id) => {
    return delis.find(deli => deli.id === id);
};

exports.save = (deli) => {
    //story.id = stories.length+1;
    deli.id = uuidv4();
    deli.price = '$11.99'
    deli.createdTime = DateTime.now().toLocaleString(DateTime.DATETIME_SHORT);
    console.log(deli);
    if(deli.title === "" && deli.content === "" && deli.category === "" ) {
        return false;
    } else {
        delis.push(deli);
        return true;
    }
    
};

exports.updateByID = (id, updatedStory) => {
    let deli = delis.find(deli => deli.id === id);
    if (deli) {
        deli.title = updatedStory.title;
        deli.price = updatedStory.price;
        deli.content = updatedStory.content;
        return true;
    } else {
        return false;
    }
};

exports.deleteByID = (id) => {
    let index = delis.findIndex(deli => deli.id === id);
    if (index !== -1) {
        delis.splice(index,1);
        // console.log("in dlt function"+id);
        return true;
    } else {
        return false;
    }
};