const express = require('express');
const morgan = require('morgan');
const deliRoutes = require('./routes/deliRoutes');
const methodOverride = require('method-override')

const app = express();

let port = 4444;
let host = 'localhost';
app.set('view engine', 'ejs');

app.use(express.static('public'));
app.use(express.urlencoded({extended: true}));
app.use(morgan('tiny'));
app.use(methodOverride('_method'));

app.get('/', (req, res) => {
    res.render('index');
})

app.use('/', deliRoutes);

app.use((req, res, next) => {
let err = new Error('Server cannot locate '+ req.url);
    err.status = 404;
    next(err);
});

app.use((err, req, res, next) => {
    console.log(err.stack);
    if(!err.status){
        err.status = 500;
        err.message = ("Internal Server Err");
    }

    res.status(err.status);
    res.render('errHandelig/Error.ejs', {error: err});
});


app.listen(port, host, () => {
    console.log("Initiated the app -->", host,port)
})